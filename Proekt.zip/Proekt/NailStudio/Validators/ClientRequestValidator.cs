﻿using NailStudio.Models.Requests;
using FluentValidation;

namespace Cinematic.Validators
{
    public class ClientRequestValidator : AbstractValidator<ClientRequest>
    {
        public ClientRequestValidator()
        {
            RuleFor(x => x.Username).NotEmpty();
            RuleFor(x => x.AmountPaid).GreaterThan(1);
        }
    }
}