﻿using FluentValidation;
using NailStudio.Models.Requests;

namespace NailStudio.Validators
{
    public class ServiceHairRequestValidator : AbstractValidator<ServiceHairRequest>
    {
        public ServiceHairRequestValidator()
        {
            RuleFor(x => x.Name).NotEmpty();
            RuleFor(x => x.Price).GreaterThan(0);
            RuleFor(x => x.Rating).IsInEnum();
        }
    }
}
