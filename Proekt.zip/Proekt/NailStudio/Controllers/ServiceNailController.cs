﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using NailStudio.BL.Interfaces;
using NailStudio.Models.DTO;
using NailStudio.Models.Requests;
using NailStudio.Models.Responses;

namespace NailStudio.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ServiceNailController : ControllerBase
    {
        private readonly IServiceNailService _nailService;
        private readonly IMapper _mapper;

        public ServiceNailController(IServiceNailService nailService, IMapper mapper)
        {
            _nailService = nailService;
            _mapper = mapper;
        }

        [HttpGet("GetAll")]
        public IActionResult GetAll()
        {
            var result = _nailService.GetAll();

            return Ok(result);
        }

        [HttpGet("GetById")]
        public IActionResult GetById(int id)
        {
            if (id <= 0) return BadRequest();

            var result = _nailService.GetById(id);

            if (result == null) return NotFound(id);
            var response = _mapper.Map<ServiceNailResponse>(result);

            return Ok(response);
        }

        [HttpPost("Create")]
        public IActionResult Create([FromBody] ServiceNailRequest nailRequest)
        {
            if (nailRequest == null) return BadRequest();

            var nail = _mapper.Map<ServiceNail>(nailRequest);

            var result = _nailService.Create(nail);

            return Ok(result);
        }

        [HttpDelete]
        public IActionResult Delete(int id)
        {
            if (id <= 0) return BadRequest(id);

            var nailToRemove = _nailService.GetById(id);

            var result = _nailService.Delete(id);

            if (result == null) return NotFound(id);

            return Ok(nailToRemove);
        }

        [HttpPost("Update")]
        public IActionResult Update([FromBody] ServiceNail nail)
        {
            if (nail == null) return BadRequest();

            var searchBill = _nailService.GetById(nail.Id);

            if (searchBill == null) return NotFound(nail.Id);

            var result = _nailService.Update(nail);

            return Ok(result);
        }
        [HttpGet("GetByPrice")]
        public IActionResult GetByPrice(double price)
        {
            var result = _nailService.GetByPricePaid(price);
            if (result == null)
            {
                return NotFound(price);

            }
            return Ok(result);
        }
        [HttpGet("GetByName")]
        public IActionResult GetByName(string name)
        {
            if (name.Length <= 1) return BadRequest();

            var result = _nailService.GetByName(name);

            if (result == null) return NotFound(name);

            var response = _mapper.Map<ServiceNailResponse>(result);

            return Ok(response);
        }
    }
}
