﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using NailStudio.BL.Interfaces;
using NailStudio.Models.DTO;
using NailStudio.Models.Requests;
using NailStudio.Models.Responses;

namespace NailStudio.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ServiceHairController : ControllerBase
    {
        private readonly IServiceHairService _hairService;
        private readonly IMapper _mapper;

        public ServiceHairController(IServiceHairService hairService, IMapper mapper)
        {
            _hairService = hairService;
            _mapper = mapper;
        }

        [HttpGet("GetAll")]
        public IActionResult GetAll()
        {
            var result = _hairService.GetAll();

            return Ok(result);
        }

        [HttpGet("GetById")]
        public IActionResult GetById(int id)
        {
            if (id <= 0) return BadRequest();

            var result = _hairService.GetById(id);

            if (result == null) return NotFound(id);
            var response = _mapper.Map<ServiceHairResponse>(result);

            return Ok(response);
        }

        [HttpPost("Create")]
        public IActionResult Create([FromBody] ServiceHairRequest hairRequest)
        {
            if (hairRequest == null) return BadRequest();

            var hair = _mapper.Map<ServiceHair>(hairRequest);

            var result = _hairService.Create(hair);

            return Ok(result);
        }

        [HttpDelete]
        public IActionResult Delete(int id)
        {
            if (id <= 0) return BadRequest(id);

            var hairToRemove = _hairService.GetById(id);

            var result = _hairService.Delete(id);

            if (result == null) return NotFound(id);

            return Ok(hairToRemove);
        }

        [HttpPost("Update")]
        public IActionResult Update([FromBody] ServiceHair hair)
        {
            if (hair == null) return BadRequest();

            var searchBill = _hairService.GetById(hair.Id);

            if (searchBill == null) return NotFound(hair.Id);

            var result = _hairService.Update(hair);

            return Ok(result);
        }
        [HttpGet("GetByPrice")]
        public IActionResult GetByPrice(double price)
        {
            var result = _hairService.GetByPricePaid(price);
            if (result == null)
            {
                return NotFound(price);

            }
            return Ok(result);
        }
        [HttpGet("GetByCliName")]
        public IActionResult GetByName(string name)
        {
            if (name.Length <= 3) return BadRequest();

            var result = _hairService.GetByName(name);

            if (result == null) return NotFound(name);
            var response = _mapper.Map<ServiceHairResponse>(result);

            return Ok(response);
        }
     
    }
 }
