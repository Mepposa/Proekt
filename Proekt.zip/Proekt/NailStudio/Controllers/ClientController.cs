﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using NailStudio.BL.Interfaces;
using NailStudio.Models.DTO;
using NailStudio.Models.Requests;
using NailStudio.Models.Responses;

namespace NailStudio.Controllers
{
    [ApiController]
    [Route("[Controller]")]
    public class ClientController : ControllerBase
    {
        private readonly IClientService _clientService;
        private readonly IMapper _mapper;

        public ClientController(IClientService clientService, IMapper mapper)
        {
            _clientService = clientService;
            _mapper = mapper;
        }
        [HttpGet("GetAll")]
        public IActionResult GetAll()
        {
            var result = _clientService.GetAll();

            return Ok(result);
        }

        [HttpGet("GetById")]
        public IActionResult GetById(int id)
        {
            if (id <= 0) return BadRequest();

            var result = _clientService.GetById(id);

            if (result == null) return NotFound(id);
            var response = _mapper.Map<ClientResponse>(result);

            return Ok(response);
        }
        [HttpPost("Create")]
        public IActionResult Create([FromBody] ClientRequest clientRequest)
        {
            if (clientRequest == null) return BadRequest();

            var client = _mapper.Map<Client>(clientRequest);

            var result = _clientService.Create(client);

            return Ok(result);
        }
        [HttpDelete]
        public IActionResult Delete(int id)
        {
            if (id <= 0) return BadRequest(id);

            var clientToDelete = _clientService.GetById(id);

            var result = _clientService.Delete(id);

            if (result == null) return NotFound(id);

            return Ok(clientToDelete);
        }
        [HttpPost("Update")]
        public IActionResult Update([FromBody] Client client)
        {
            if (client == null) return BadRequest();

            var searchBill = _clientService.GetById(client.Id);

            if (searchBill == null) return NotFound(client.Id);

            var result = _clientService.Update(client);

            return Ok(result);
        }
        [HttpPost("Pay Procedure")]
        public IActionResult Buy(string clientname, string buyName)
        {
            var result = _clientService.Buy(clientname, buyName);

            return Ok(result);
        }
        [HttpGet("GetClientByClientname")]
        public IActionResult GetUserByUsername(string name)
        {
            if (name.Length <= 3) return BadRequest();

            var result = _clientService.GetClientByClientname(name);

            if (result == null) return NotFound(name);
            var response = _mapper.Map<ClientResponse>(result);

            return Ok(response);
        }
    }
}
