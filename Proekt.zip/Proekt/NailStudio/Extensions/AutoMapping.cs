﻿using AutoMapper;
using NailStudio.Models.DTO;
using NailStudio.Models.Requests;
using NailStudio.Models.Responses;


namespace NailStudio.Extensions
{
    public class AutoMapping : Profile
    {
        public AutoMapping()
        {

            CreateMap<ServiceHair, ServiceHairResponse>().ReverseMap();
            CreateMap<ServiceHairResponse, ServiceHair>().ReverseMap();
            CreateMap<ServiceHairRequest, ServiceHair>().ReverseMap();

            CreateMap<Client, ClientResponse>().ReverseMap();
            CreateMap<ClientResponse, Client>().ReverseMap();
            CreateMap<ClientRequest, Client>().ReverseMap();

            CreateMap<ServiceNail, ServiceNailResponse>().ReverseMap();
            CreateMap<ServiceNailResponse, ServiceNail>().ReverseMap();
            CreateMap<ServiceNailRequest, ServiceNail>().ReverseMap();
        }

    }
}
