﻿using NailStudio.Models.DTO;
using System.Collections.Generic;

namespace NailStudio.DL.Interfaces
{
    public interface  IServiceHairRepository
    {
        ServiceHair Create(ServiceHair hair);

        ServiceHair Update(ServiceHair hair);

        ServiceHair Delete(int id);

        ServiceHair GetById(int id);

        IEnumerable<ServiceHair> GetAll();
    }
}
