﻿using Microsoft.Extensions.Options;
using MongoDB.Driver;
using NailStudio.DL.Interfaces;
using NailStudio.Models.Common;
using NailStudio.Models.DTO;
using System.Collections.Generic;

namespace NailStudio.DL.Mongo
{
    public class ServiceNailMongoRepository : IServiceNailRepository
    {
        private readonly IMongoCollection<ServiceNail> _nailCollection;

        public ServiceNailMongoRepository(IOptions<MongoDbConfiguration> config)
        {
            var client = new MongoClient(config.Value.ConnectionString);
            var database = client.GetDatabase(config.Value.DatabaseName);

            _nailCollection = database.GetCollection<ServiceNail>("ServiceNail");
        }

        public ServiceNail Create(ServiceNail nail)
        {
            _nailCollection.InsertOne(nail);

            return nail;
        }

        public ServiceNail Delete(int id)
        {
            var nail = GetById(id);
            _nailCollection.DeleteOne(ServiseNail => ServiseNail.Id == id);

            return nail;
        }

        public IEnumerable<ServiceNail> GetAll()
        {
            return _nailCollection.Find(ServiceNail => true).ToList();
        }

        public ServiceNail GetById(int id)
        {
            return _nailCollection.Find(Series => Series.Id == id).FirstOrDefault();
        }

        public ServiceNail Update(ServiceNail nail)
        {
            _nailCollection.ReplaceOne(serieToReplace => serieToReplace.Id == nail.Id, nail);
            return nail;
        }
    }
}
