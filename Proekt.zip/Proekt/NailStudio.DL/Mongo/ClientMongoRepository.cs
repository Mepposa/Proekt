﻿using Microsoft.Extensions.Options;
using MongoDB.Driver;
using NailStudio.DL.Interfaces;
using NailStudio.Models.Common;
using NailStudio.Models.DTO;
using System.Collections.Generic;

namespace NailStudio.DL.Mongo
{
    class ClientMongoRepository : IClientRepository
    {

        private readonly IMongoCollection<Client> _clientCollection;
        public ClientMongoRepository(IOptions<MongoDbConfiguration> config)
        {
            var client = new MongoClient(config.Value.ConnectionString);
            var database = client.GetDatabase(config.Value.DatabaseName);

            _clientCollection = database.GetCollection<Client>("Clients");
        }
        public Client Create(Client client)
        {
            _clientCollection.InsertOne(client);

            return client;
        }

        public Client Delete(int id)
        {
            var client = GetById(id);
            _clientCollection.DeleteOne(Client => Client.Id == id);

            return client;
        }

        public IEnumerable<Client> GetAll()
        {
            return _clientCollection.Find(Client => true).ToList();
        }

        public Client GetById(int id)
        {
            return _clientCollection.Find(Client => Client.Id == id).FirstOrDefault();
        }

        public Client Update(Client client)
        {
            _clientCollection.ReplaceOne(userToReplace => userToReplace.Id == client.Id, client);
            return client;
        }
    }
}
