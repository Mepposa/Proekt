﻿using Microsoft.Extensions.Options;
using MongoDB.Driver;
using NailStudio.DL.Interfaces;
using NailStudio.Models.Common;
using NailStudio.Models.DTO;
using System.Collections.Generic;

namespace NailStudio.DL.Mongo
{
    public class ServiceHairMongoRepository : IServiceHairRepository
    {
        private readonly IMongoCollection<ServiceHair> _hairCollection;

        public ServiceHairMongoRepository(IOptions<MongoDbConfiguration> config)
        {
            var client = new MongoClient(config.Value.ConnectionString);
            var database = client.GetDatabase(config.Value.DatabaseName);

            _hairCollection = database.GetCollection<ServiceHair>("ServiceHair");
        }

        public ServiceHair Create(ServiceHair hair)
        {
            _hairCollection.InsertOne(hair);

            return hair;
        }

        public ServiceHair Update(ServiceHair hair)
        {
            _hairCollection.ReplaceOne(hairToReplace => hairToReplace.Id == hair.Id, hair);
            return hair;
        }

        public ServiceHair Delete(int id)
        {
            var hair = GetById(id);
            _hairCollection.DeleteOne(ServiceHair => ServiceHair.Id == id);

            return hair;
        }

        public ServiceHair GetById(int id)
        {
            return _hairCollection.Find(ServiceHair => ServiceHair.Id == id).FirstOrDefault();
        }

        public IEnumerable<ServiceHair> GetAll()
        {
            return _hairCollection.Find(ServiceHair => true).ToList();
        }
    }
}
