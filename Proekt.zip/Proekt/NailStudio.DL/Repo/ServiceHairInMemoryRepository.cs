﻿using NailStudio.DL.InMemoryCollection;
using NailStudio.DL.Interfaces;
using NailStudio.Models.DTO;
using System.Collections.Generic;
using System.Linq;

namespace NailStudio.DL.Repo
{
    public class ServiceHairInMemoryRepository : IServiceHairRepository
    {
        public ServiceHairInMemoryRepository()
        {

        }
        public ServiceHair Create(ServiceHair hair)
        {
            ServiceHairInMemoryCollection.ServiceHairDB.Add(hair);
            return hair;
        }

        public ServiceHair Delete(int id)
        {
            var hair = ServiceHairInMemoryCollection.ServiceHairDB.FirstOrDefault(nail => nail.Id == id);

            ServiceHairInMemoryCollection.ServiceHairDB.Remove(hair);

            return hair;
        }

        public IEnumerable<ServiceHair> GetAll()
        {
            return ServiceHairInMemoryCollection.ServiceHairDB;
        }

        public ServiceHair GetById(int id)
        {
            return ServiceHairInMemoryCollection.ServiceHairDB.FirstOrDefault(nail => nail.Id == id); ;
        }

        public ServiceHair Update(ServiceHair hair)
        {
            var result = ServiceHairInMemoryCollection.ServiceHairDB.FirstOrDefault(x => x.Id == hair.Id);

            result.Name = hair.Name;
            result.Price = hair.Price;
            result.Rating = hair.Rating;

            return result;
        }
    }
}
