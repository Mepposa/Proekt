﻿using NailStudio.DL.InMemoryCollection;
using NailStudio.DL.Interfaces;
using NailStudio.Models.DTO;
using System.Collections.Generic;
using System.Linq;

namespace NailStudio.DL.Repo
{
    public class ClientInMemoryRepository : IClientRepository
    {
        public ClientInMemoryRepository()
        {

        }
        public Client Create(Client client)
        {
            ClientInMemoryCollection.ClientsDB.Add(client);
            return client;
        }

        public Client Delete(int id)
        {
            var client = ClientInMemoryCollection.ClientsDB.FirstOrDefault(client => client.Id == id);
            ClientInMemoryCollection.ClientsDB.Remove(client);
            return client;
        }

        public IEnumerable<Client> GetAll()
        {
            return ClientInMemoryCollection.ClientsDB;
        }

        public Client GetById(int id)
        {
            return ClientInMemoryCollection.ClientsDB.FirstOrDefault(client => client.Id == id);
        }

        public Client Update(Client client)
        {
           var result = ClientInMemoryCollection.ClientsDB.FirstOrDefault(x=> x.Id == client.Id);
            result.Clientname = client.Clientname;
            result.AmountPaid = client.AmountPaid;

            return result;
        }
    }
}
