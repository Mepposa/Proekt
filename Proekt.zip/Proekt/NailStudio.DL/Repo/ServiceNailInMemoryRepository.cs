﻿using NailStudio.DL.InMemoryCollection;
using NailStudio.DL.Interfaces;
using NailStudio.Models.DTO;
using System.Collections.Generic;
using System.Linq;

namespace NailStudio.DL.Repo
{
    public class ServiceNailInMemoryRepository : IServiceNailRepository
    {
        public ServiceNailInMemoryRepository()
        {

        }
        public ServiceNail Create(ServiceNail nail)
        {
           ServiceNailInMemoryCollection.ServiceNailDB.Add(nail);
            return nail;
        }

        public ServiceNail Delete(int id)
        {
            var nail = ServiceNailInMemoryCollection.ServiceNailDB.FirstOrDefault(nail => nail.Id == id);

            ServiceNailInMemoryCollection.ServiceNailDB.Remove(nail);

            return nail;
        }

        public IEnumerable<ServiceNail> GetAll()
        {
            return ServiceNailInMemoryCollection.ServiceNailDB;
        }

        public ServiceNail GetById(int id)
        {
            return ServiceNailInMemoryCollection.ServiceNailDB.FirstOrDefault(nail => nail.Id == id); ;
        }

        public ServiceNail Update(ServiceNail nail)
        {
            var result = ServiceNailInMemoryCollection.ServiceNailDB.FirstOrDefault(x => x.Id == nail.Id);

            result.Name = nail.Name;
            result.Price = nail.Price;
            result.Rating = nail.Rating;

            return result;
        }
    }
}
