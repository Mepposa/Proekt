﻿using NailStudio.Models.DTO;
using System;
using System.Collections.Generic;
using System.Text;

namespace NailStudio.DL.InMemoryCollection
{
    public class ServiceNailInMemoryCollection
    {
        public static List<ServiceNail> ServiceNailDB = new List<ServiceNail>
        {
             new ServiceNail()
              {
             Id=1,
             Name="Acrylic Full Set",
             Duration=300,
             Rating=Models.Enums.RatingService.Good,
             Price=60

            },
           new ServiceNail()
             {
             Id=2,
             Name="Gel Full Set",
             Duration=240,
             Rating=Models.Enums.RatingService.Excellent,
             Price=60

            },
              new ServiceNail()
            {
             Id=3,
             Name="PolyGel Full Set",
             Duration=180,
             Rating=Models.Enums.RatingService.Good,
             Price=60

            },
        };
    }
}
