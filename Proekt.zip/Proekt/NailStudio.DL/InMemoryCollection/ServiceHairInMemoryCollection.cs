﻿using NailStudio.Models.DTO;
using System;
using System.Collections.Generic;
using System.Text;

namespace NailStudio.DL.InMemoryCollection
{
   public class ServiceHairInMemoryCollection
    {
        public static List<ServiceHair> ServiceHairDB = new List<ServiceHair>
        {
             new ServiceHair()
        {
             Id=1,
             Name="Hair Cut",
             Duration=30,
             Rating=Models.Enums.RatingService.Excellent,             
             Price=12

            },
           new ServiceHair()
        {
             Id=2,
             Name="Full Highlights",
             Duration=180,
             Rating=Models.Enums.RatingService.Average,            
             Price=80

            },
              new ServiceHair()
        {
             Id=3,
             Name="Blow Dry with curling or flat iron",
             Duration=60,
             Rating=Models.Enums.RatingService.Good,            
             Price=20

            },
        };
    }
}
