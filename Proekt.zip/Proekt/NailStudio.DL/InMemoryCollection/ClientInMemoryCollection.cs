﻿using NailStudio.Models.DTO;
using System.Collections.Generic;

namespace NailStudio.DL.InMemoryCollection
{
    public class ClientInMemoryCollection
    {
        public static List<Client> ClientsDB = new List<Client>
        {
            new Client()
            {
                Id=1,
                Clientname="A",
                AmountPaid=5,

            },
              new Client()
            {
                Id=2,
                Clientname="B",
                AmountPaid=10,

            },
                new Client()
            {
                Id=3,
                Clientname="C",
                AmountPaid=15,

            },
        };
    }
}
