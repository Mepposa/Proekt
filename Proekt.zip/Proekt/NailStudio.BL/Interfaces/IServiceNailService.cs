﻿using NailStudio.Models.DTO;
using System.Collections.Generic;

namespace NailStudio.BL.Interfaces
{
    public interface IServiceNailService
    {
        IEnumerable<ServiceNail> GetByPricePaid(double pricepaid);
        ServiceNail GetByName(string name);
        ServiceNail Create(ServiceNail nail);
        ServiceNail Update(ServiceNail nail);
        ServiceNail Delete(int id);
        ServiceNail GetById(int id);
        IEnumerable<ServiceNail> GetAll();
    }
}
