﻿using System;
using System.Collections.Generic;
using System.Text;
using NailStudio.Models.DTO;

namespace NailStudio.BL.Interfaces
{
   public interface IServiceHairService
    {
        IEnumerable<ServiceHair> GetByPricePaid(double pricepaid);
        ServiceHair GetByName(string name);
        ServiceHair Create(ServiceHair hair);
        ServiceHair Update(ServiceHair hair);
        ServiceHair Delete(int id);
        ServiceHair GetById(int id);
        IEnumerable<ServiceHair> GetAll();

    }
}
