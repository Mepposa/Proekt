﻿using NailStudio.Models.DTO;
using System.Collections.Generic;

namespace NailStudio.BL.Interfaces
{
    public interface  IClientService
    {
        Client GetClientByClientname(string name);
        IEnumerable<Client> GetAll();
        string Buy(string clientname, string buyName);
        Client Create(Client client);
        Client Update(Client client);
        Client Delete(int id);
        Client GetById(int id);

    }
}
