﻿using NailStudio.BL.Interfaces;
using NailStudio.DL.Interfaces;
using NailStudio.Models.DTO;
using System.Collections.Generic;
using System.Linq;

namespace NailStudio.BL.Services
{
    public class ClientService : IClientService
    {
        private readonly IClientRepository _clientRepository;
        public readonly IServiceNailRepository _nailRepository;
        public readonly IServiceHairRepository _hairRepository;

        public ClientService(IClientRepository clientRepository, IServiceNailRepository nailRepository, IServiceHairRepository hairRepository)
        {
            _clientRepository = clientRepository;
            _nailRepository = nailRepository;
            _hairRepository = hairRepository;
        }

        public Client Create(Client client)
        {
            var index = _clientRepository.GetAll().OrderByDescending(x => x.Id).FirstOrDefault()?.Id;

            client.Id = (int)(index != null ? index + 1 : 1);

            return _clientRepository.Create(client);
        }

        public Client Delete(int id)
        {
            return _clientRepository.Delete(id);
        }

        public IEnumerable<Client> GetAll()
        {
            return _clientRepository.GetAll();
        }

        public Client GetById(int id)
        {
            return _clientRepository.GetById(id);
        }

        public Client GetClientByClientname(string name)
        {
            var result = _clientRepository.GetAll().FirstOrDefault(x => x.Clientname == name);

            return result;
        }

        public Client Update(Client client)
        {
            return _clientRepository.Update(client);
        }

        public string Buy(string clientname, string buyName)
        {
            var client = GetClientByClientname(clientname);
            ServiceHair hairPrice = null;
            ServiceNail nailPrice = null;

            var hairs = _hairRepository.GetAll();
            foreach (var hair in hairs)
            {
                if (hair.Name == buyName)
                {
                    hairPrice = hair;
                    break;
                }
            }
            var nails = _nailRepository.GetAll();
            foreach (var nail in nails)
            {
                if (nail.Name == buyName)
                {
                    nailPrice = nail;
                    break;
                }
            }
            if (hairPrice != null)
            {
                if (client.AmountPaid >= hairPrice.Price)
                {
                    client.AmountPaid -= hairPrice.Price;
                    return string.Format("User {0} buy {1}", client.Clientname, hairPrice.Name);
                }
                else
                {
                    return "Not enough money for the procedure";
                }

            }

            if (nailPrice != null)
            {
                if (client.AmountPaid >= nailPrice.Price)
                {
                    return string.Format("User {0} buy {1}", client.Clientname, nailPrice.Name);
                }
                else
                {
                    return "Not enough money for the procedure";
                }

            }
            return "Not Found";
        }
    }
}
