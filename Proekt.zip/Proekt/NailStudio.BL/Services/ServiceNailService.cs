﻿using NailStudio.BL.Interfaces;
using NailStudio.DL.Interfaces;
using NailStudio.Models.DTO;
using System.Collections.Generic;
using System.Linq;
using Serilog;
using System;

namespace NailStudio.BL.Services
{
   public class ServiceNailService : IServiceNailService
    {
        public readonly IServiceNailRepository _nailRepository;
        private readonly ILogger _logger;

        public ServiceNailService (IServiceNailRepository nailRepository, ILogger logger)
        {
            _nailRepository = nailRepository;
            _logger = logger;
        }
        public ServiceNail Create(ServiceNail nail)
        {
            try
            {
                var index = _nailRepository.GetAll().OrderByDescending(x => x.Id).FirstOrDefault()?.Id;

                nail.Id = (int)(index != null ? index + 1 : 1);

                return _nailRepository.Create(nail);
            }
            catch (Exception e)
            {
                _logger.Error(e.Message);
            }

            return _nailRepository.Create(nail);
        }

        public ServiceNail Delete(int id)
        {
            return _nailRepository.Delete(id);
        }

        public IEnumerable<ServiceNail> GetAll()
        {
            try
            {
                return _nailRepository.GetAll();
            }
            catch (Exception e)
            {

                _logger.Error(e.Message);
            }
            return _nailRepository.GetAll();
        }

        public ServiceNail GetById(int id)
        {
            return _nailRepository.GetById(id);
        }

        public ServiceNail GetByName(string name)
        {
            try
            {
                return _nailRepository.GetAll().FirstOrDefault(x => x.Name == name);
            }
            catch (Exception e)
            {
                _logger.Error(e.Message);
            }
            return _nailRepository.GetAll().FirstOrDefault(x => x.Name == name);

        }

        public IEnumerable<ServiceNail> GetByPricePaid(double pricepaid)
        {
            var result = _nailRepository.GetAll().Where(x => x.Price <= pricepaid);

            return result;
        }

        public ServiceNail Update(ServiceNail nail)
        {
            return _nailRepository.Update(nail);
        }
    }
}
