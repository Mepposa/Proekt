﻿using NailStudio.BL.Interfaces;
using NailStudio.DL.Interfaces;
using NailStudio.Models.DTO;
using System.Collections.Generic;
using System.Linq;

namespace NailStudio.BL.Services
{
    public class ServiceHairService : IServiceHairService
    {
        public readonly IServiceHairRepository _hairRepository;
        public ServiceHairService(IServiceHairRepository hairRepository)
        {
            _hairRepository = hairRepository;
        }
        public ServiceHair Create(ServiceHair hair)
        {
            var index = _hairRepository.GetAll().OrderByDescending(x => x.Id).FirstOrDefault()?.Id;

            hair.Id = (int)(index != null ? index + 1 : 1);

            return _hairRepository.Create(hair);
        }
    
        public ServiceHair Delete(int id)
        {

            return _hairRepository.Delete(id);
        }

        public IEnumerable<ServiceHair> GetAll()
        {
            return _hairRepository.GetAll();
        }

        public ServiceHair GetById(int id)
        {
            return _hairRepository.GetById(id); 
        }

        public ServiceHair GetByName(string name)
        {
            var result = _hairRepository.GetAll().FirstOrDefault(x => x.Name == name);

            return result;
        }

        public IEnumerable<ServiceHair> GetByPricePaid(double pricepaid)
        {
            var result = _hairRepository.GetAll().Where(x => x.Price <= pricepaid);

            return result;
        }

        public ServiceHair Update(ServiceHair hair)
        {
            return _hairRepository.Update(hair);

        }
    }
}
