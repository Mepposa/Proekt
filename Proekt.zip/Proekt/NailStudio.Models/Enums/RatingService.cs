﻿namespace NailStudio.Models.Enums
{
    public enum RatingService
    {
        Terrible = 1,
        Bad = 2,
        Average = 3,
        Good = 4,
        Excellent = 5
    }
}
