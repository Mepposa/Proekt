﻿using NailStudio.Models.Enums;

namespace NailStudio.Models.DTO
{
    public   class ServiceNail
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double Duration { get; set; }
        public RatingService Rating { get; set; }
        public double Price { get; set; }
    }
}
