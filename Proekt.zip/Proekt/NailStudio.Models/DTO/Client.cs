﻿namespace NailStudio.Models.DTO
{
    public class Client
    {
        public int Id { get; set; }
        public string Clientname { get; set; }
        public double AmountPaid { get; set; }
    }
}
