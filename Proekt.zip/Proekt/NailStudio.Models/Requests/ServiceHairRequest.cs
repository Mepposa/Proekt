﻿using NailStudio.Models.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace NailStudio.Models.Requests
{
   public class ServiceHairRequest
    {
        public string Name { get; set; }
        public double Duration { get; set; }
        public RatingService Rating { get; set; }
        public double Price { get; set; }
    }
}
