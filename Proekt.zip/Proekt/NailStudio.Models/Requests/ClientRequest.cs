﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NailStudio.Models.Requests
{
   public class ClientRequest
    {
        public string Username { get; set; }
        public double AmountPaid { get; set; }
    }
}
