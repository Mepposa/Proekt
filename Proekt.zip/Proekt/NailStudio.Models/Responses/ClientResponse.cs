﻿namespace NailStudio.Models.Responses
{
    public class ClientResponse
    {
        public int Id { get; set; }
        public string Username { get; set; }
        public double AmountPaid { get; set; }
    }
}
